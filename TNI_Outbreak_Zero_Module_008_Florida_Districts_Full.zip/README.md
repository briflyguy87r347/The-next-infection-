# THE NEXT INFECTION — OUTBREAK ZERO / Module 008

Android-first Godot 4.x prototype, built on the original Module 006 game plus the Module 007 visitable-settlement changes.

## Playable modes
- **Survival Arena**: current Block Zero arena, doubled zombie waves, health/token station, mystery gun, permanent Bank points deposit on death/extraction, first-person gun.
- **Florida Map**: choose **Cypress Haven / Orlando** or **Bayfront Yards / Tampa**, inspect the 4×4 square plots in each region, claim and build with Fabrication Tokens, travel to an explorable 3D district. Offline local demo, not real geographic geometry or multiplayer competition.
- **Gunsmith**: pistol initially owned. Crafted guns are permanent starting-loadout options. Gun parts and Fabrication Tokens come from successfully extracted scavenging loot.
- **Original Settlement**: visit the safehouse, workshop, generator pad and barricades from Module 007. Bank purchases for deeds and blueprint still live outside survival runs.

## New controls
- On Android, **PUNCH / KICK / KNIFE** touch buttons near the lower center, plus regular FIRE, RELOAD, USE and movement.
- On desktop: **F** punch, **G** kick, **V** knife.
- Scavenged blue gun-part drops, yellow fabrication drops, green health and brown ammo auto-pick up when nearby. Gun parts and fabrication drops survive only successful extraction.

## Persistence
`user://survival_bank_v1.json` — bank credits, deeds, existing production.
`user://tni_world_progress_v1.json` — owned plot IDs, world buildings, crafted weapons, preferred starter weapon and fabrication/parts inventory.

## Import on Android
From Godot Project Manager -> Import -> choose this ZIP -> choose a NEW folder, or extract preserving `project.godot` in the root and select it. Retain your existing Module 006 project as backup. Select **Start New Survival Run** or the new menus. Player progression is saved in the application's user-data directory, not inside the ZIP.

## Important limitations
Procedural/blocky art and fictional square sectors; not photorealistic nor an accurate mapped recreation of Florida. Ownership, resource production and rewards are client-side offline prototypes; no online player domination and no withdrawable real-money yield. Needs an actual Godot runtime/Android device test before merging to main.

See `docs/MODULE_008_FLORIDA_WORLD_DESIGN.md` for the roadmap and economics.
