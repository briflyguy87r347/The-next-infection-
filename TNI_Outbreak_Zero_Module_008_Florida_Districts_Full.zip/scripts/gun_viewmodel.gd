class_name GunViewmodel
extends Node3D

# Lightweight 3D first-person prototype weapon. No external models required.
var _shape_root: Node3D
var _flash: MeshInstance3D
var _flash_timer: float = 0.0
var _kick: float = 0.0
var _home: Vector3 = Vector3(0.33, -0.32, -0.68)


func _ready() -> void:
	position = _home
	_shape_root = Node3D.new()
	add_child(_shape_root)
	set_weapon("pistol")


func set_weapon(id: String) -> void:
	if not is_instance_valid(_shape_root):
		return
	for node in _shape_root.get_children():
		_shape_root.remove_child(node)
		node.queue_free()
	var steel := Color(0.22, 0.25, 0.27)
	var dark := Color(0.07, 0.08, 0.09)
	var accent := Color(0.34, 0.28, 0.23)
	var length := 0.43
	var grip_width := 0.075
	match id:
		"smg":
			steel = Color(0.17, 0.22, 0.24)
			length = 0.60
		"rifle":
			steel = Color(0.22, 0.27, 0.25)
			length = 0.82
		"shotgun":
			steel = Color(0.34, 0.29, 0.22)
			length = 0.90
		"lmg":
			steel = Color(0.29, 0.29, 0.27)
			length = 0.88
			grip_width = 0.11
	_make_box(Vector3(0, 0, -length * 0.34), Vector3(0.15, 0.15, length * 0.68), steel)
	_make_box(Vector3(0, -0.12, -0.06), Vector3(grip_width, 0.27, 0.12), accent)
	# Simple low-poly sleeve and support hand give the weapon a held appearance.
	_make_box(Vector3(0.10, -0.31, 0.16), Vector3(0.18, 0.27, 0.26), Color(0.22, 0.28, 0.25))
	_make_box(Vector3(0.10, -0.14, 0.01), Vector3(0.11, 0.14, 0.13), Color(0.52, 0.39, 0.30))
	_make_box(Vector3(0, 0.11, -0.10), Vector3(0.08, 0.05, 0.19), dark)
	_make_box(Vector3(0, -0.05, -length * 0.88), Vector3(0.07, 0.07, length * 0.48), dark)
	if id != "pistol":
		_make_box(Vector3(0, -0.12, -length * 0.46), Vector3(0.07, 0.22, 0.1), dark)
	if id == "lmg":
		_make_box(Vector3(0, -0.15, -0.27), Vector3(0.19, 0.27, 0.17), Color(0.23, 0.25, 0.24))
	if id == "shotgun":
		_make_box(Vector3(0, 0.095, -0.52), Vector3(0.08, 0.045, 0.45), dark)
	_flash = MeshInstance3D.new()
	var flash_mesh := SphereMesh.new()
	flash_mesh.radius = 0.085
	flash_mesh.height = 0.16
	_flash.mesh = flash_mesh
	_flash.position = Vector3(0, -0.05, -length * 1.12)
	var fire_material := StandardMaterial3D.new()
	fire_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fire_material.albedo_color = Color(1.0,0.81,0.35)
	fire_material.emission_enabled = true
	fire_material.emission = Color(1.0,0.47,0.07)
	fire_material.emission_energy_multiplier = 2.0
	_flash.material_override = fire_material
	_flash.visible = false
	_shape_root.add_child(_flash)


func _make_box(at: Vector3, dim: Vector3, col: Color) -> void:
	var part := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dim
	part.mesh = mesh
	part.position = at
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.metallic = 0.15
	mat.roughness = 0.58
	part.material_override = mat
	_shape_root.add_child(part)


func fire() -> void:
	_kick = 1.0
	_flash_timer = 0.065
	if is_instance_valid(_flash):
		_flash.visible = true


func _process(delta: float) -> void:
	_kick = move_toward(_kick, 0.0, delta * 10.0)
	position = _home + Vector3(0, 0.018 * _kick, 0.10 * _kick)
	rotation.x = -0.12 * _kick
	if _flash_timer > 0.0:
		_flash_timer -= delta
		if _flash_timer <= 0.0 and is_instance_valid(_flash):
			_flash.visible = false
