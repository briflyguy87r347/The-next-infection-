extends Node3D

const PLAYER: PackedScene = preload("res://scenes/player.tscn")
const HUD: PackedScene = preload("res://scenes/hud.tscn")

var _player: FirstPersonPlayer

func _ready() -> void:
	var world := DistrictWorld.new()
	add_child(world)
	_player = PLAYER.instantiate() as FirstPersonPlayer
	add_child(_player)
	_player.global_position = Vector3(0,0.13,46)
	var hud := HUD.instantiate() as TouchHUD
	add_child(hud)
	hud.set_combat_controls_visible(false)
	hud.move_changed.connect(_player.set_mobile_movement)
	hud.look_changed.connect(_player.apply_touch_look)
	hud.jump_pressed.connect(_player.request_jump)
	hud.sprint_changed.connect(_player.set_mobile_sprinting)
	_player.health_changed.connect(hud.set_health)
	hud.set_health(_player.health, _player.maximum_health)
	var overlay := CanvasLayer.new()
	add_child(overlay)
	var caption := Label.new()
	caption.position = Vector2(20, 88)
	caption.text = "DISTRICT EXPLORATION — OFFLINE PROTOTYPE\nClaim plots and build from FLORIDA MAP"
	caption.add_theme_font_size_override("font_size",16)
	overlay.add_child(caption)
	var map_button := Button.new()
	map_button.text = "FLORIDA MAP"
	map_button.position = Vector2(754, 14)
	map_button.size = Vector2(190,50)
	map_button.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/world_map.tscn"))
	overlay.add_child(map_button)
