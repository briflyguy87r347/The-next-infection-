class_name WorldProgress
extends RefCounted

# Offline prototype ledger; server-authoritative ownership is required for multiplayer.
# Separate from the match-points SurvivalBank. No active match can withdraw these funds.
const SAVE: String = "user://tni_world_progress_v1.json"
const REGIONS: Dictionary = {"orlando":"CYPRESS HAVEN — ORLANDO", "tampa":"BAYFRONT YARDS — TAMPA"}
const RECIPES: Dictionary = {
    "smg":{"name":"RAPID SMG", "parts":3, "tokens":2},
    "shotgun":{"name":"BREACH SHOTGUN", "parts":4, "tokens":3},
    "rifle":{"name":"PATROL RIFLE", "parts":6, "tokens":4},
    "lmg":{"name":"SUPPORT LMG", "parts":10, "tokens":7}
}
const BUILDINGS: Dictionary = {
    "generator":{"name":"GENERATOR", "tokens":3},
    "workshop":{"name":"SALVAGE WORKSHOP", "tokens":4},
    "watchtower":{"name":"WATCHTOWER", "tokens":5},
    "supply_cache":{"name":"SUPPLY CACHE", "tokens":2}
}

static func fresh() -> Dictionary:
    return {"version":1,"region":"orlando","plot":"O-01","plots":{"O-01":[]},
        "owned_weapons":["pistol"],"starting_weapon":"pistol",
        "gun_parts":0,"fabrication_tokens":0,"production_last":int(Time.get_unix_time_from_system()),"processed_runs":[]}

static func load_data() -> Dictionary:
    var data: Dictionary = fresh()
    if not FileAccess.file_exists(SAVE):
        return data
    var file := FileAccess.open(SAVE, FileAccess.READ)
    if file == null:
        data["read_error"] = true
        return data
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary) or int(parsed.get("version", -1)) != 1:
        data["read_error"] = true
        return data
    for key in ["region","plot","plots","owned_weapons","starting_weapon","gun_parts","fabrication_tokens","production_last","processed_runs"]:
        if parsed.has(key):
            data[key] = parsed[key]
    if not (data["plots"] is Dictionary) or not (data["owned_weapons"] is Array):
        data["read_error"] = true
        return data
    data["gun_parts"] = maxi(0, int(data["gun_parts"]))
    data["fabrication_tokens"] = maxi(0, int(data["fabrication_tokens"]))
    return data

static func _save(data: Dictionary) -> bool:
    if data.has("read_error"):
        return false
    var path: String = SAVE + ".tmp"
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(data, "  "))
    file.flush()
    file.close()
    return DirAccess.rename_absolute(ProjectSettings.globalize_path(path), ProjectSettings.globalize_path(SAVE)) == OK

static func select_plot(region: String, plot_id: String) -> bool:
    if not REGIONS.has(region) or not valid_plot(plot_id, region):
        return false
    var d: Dictionary = load_data()
    if d.has("read_error"):
        return false
    d["region"] = region
    d["plot"] = plot_id
    return _save(d)

static func valid_plot(plot_id: String, region: String) -> bool:
    var prefix: String = "O-" if region == "orlando" else "T-"
    if not plot_id.begins_with(prefix):
        return false
    var number: int = int(plot_id.substr(2))
    return number >= 1 and number <= 16 and plot_id == "%s%02d" % [prefix, number]

static func claim_plot() -> Dictionary:
    var d: Dictionary = load_data()
    if d.has("read_error"):
        return {"ok":false,"message":"Save unreadable"}
    var p: String = str(d["plot"])
    var plots: Dictionary = d["plots"]
    if plots.has(p):
        return {"ok":false,"message":"Plot already owned"}
    if int(d["fabrication_tokens"]) < 10:
        return {"ok":false,"message":"Need 10 Fabrication Tokens to claim"}
    d["fabrication_tokens"] = int(d["fabrication_tokens"]) - 10
    plots[p] = []
    d["plots"] = plots
    return {"ok":_save(d),"message":"Claimed %s" % p}

static func craft_gun(id: String) -> Dictionary:
    var d: Dictionary = load_data()
    if d.has("read_error") or not RECIPES.has(id):
        return {"ok":false,"message":"Unknown recipe or unreadable save"}
    if (d["owned_weapons"] as Array).has(id):
        return {"ok":false,"message":"Weapon already owned"}
    var recipe: Dictionary = RECIPES[id]
    if int(d["gun_parts"]) < int(recipe["parts"]) or int(d["fabrication_tokens"]) < int(recipe["tokens"]):
        return {"ok":false,"message":"Need %d parts and %d Fabrication Tokens" % [int(recipe["parts"]), int(recipe["tokens"])]}
    d["gun_parts"] = int(d["gun_parts"]) - int(recipe["parts"])
    d["fabrication_tokens"] = int(d["fabrication_tokens"]) - int(recipe["tokens"])
    (d["owned_weapons"] as Array).append(id)
    return {"ok":_save(d),"message":"Crafted %s permanently" % str(recipe["name"])}

static func equip(id: String) -> Dictionary:
    var d: Dictionary = load_data()
    if d.has("read_error") or not (d["owned_weapons"] as Array).has(id):
        return {"ok":false,"message":"Weapon not owned"}
    d["starting_weapon"] = id
    return {"ok":_save(d),"message":"Starting weapon set to %s" % id.to_upper()}

static func build(kind: String) -> Dictionary:
    var d: Dictionary = load_data()
    if d.has("read_error") or not BUILDINGS.has(kind):
        return {"ok":false,"message":"Build unavailable"}
    var plots: Dictionary = d["plots"]
    var p: String = str(d["plot"])
    if not plots.has(p):
        return {"ok":false,"message":"Claim this plot first"}
    var structures: Array = plots[p]
    if structures.has(kind):
        return {"ok":false,"message":"Already built here"}
    var cost: int = int(BUILDINGS[kind]["tokens"])
    if int(d["fabrication_tokens"]) < cost:
        return {"ok":false,"message":"Need %d Fabrication Tokens" % cost}
    d["fabrication_tokens"] = int(d["fabrication_tokens"]) - cost
    structures.append(kind)
    plots[p] = structures
    d["plots"] = plots
    if kind == "workshop":
        d["production_last"] = int(Time.get_unix_time_from_system())
    return {"ok":_save(d),"message":"Built %s at %s" % [kind.to_upper(),p]}

static func claim_production() -> Dictionary:
    var d: Dictionary = load_data()
    if d.has("read_error"):
        return {"ok":false,"message":"Save unavailable"}
    var production: int = 0
    for plot in (d["plots"] as Dictionary).values():
        if plot is Array and (plot as Array).has("workshop") and (plot as Array).has("generator"):
            production += 1
    if production == 0:
        return {"ok":false,"message":"Build a generator and workshop on the same plot"}
    var now: int = int(Time.get_unix_time_from_system())
    var elapsed: int = maxi(0, now - int(d["production_last"]))
    # Prototype cap 12 offline fabrication tokens per visit and 1 token / 30 minutes / powered workshop.
    var tokens: int = mini(12, int(elapsed / 1800) * production)
    if tokens == 0:
        return {"ok":true,"message":"No fabrication tokens ready yet"}
    d["fabrication_tokens"] = int(d["fabrication_tokens"]) + tokens
    d["production_last"] = now
    return {"ok":_save(d),"message":"Collected %d Fabrication Tokens" % tokens}

static func deposit_extracted_loot(run_id: String, parts: int, tokens: int) -> Dictionary:
    # Prototype save keeps credits and processed run ID in the same atomic write.
    # The later multiplayer backend must validate these rewards server-side.
    var d: Dictionary = load_data()
    if d.has("read_error") or run_id.is_empty():
        return {"ok":false,"message":"Cannot save loot"}
    var ids: Array = d["processed_runs"]
    if ids.has(run_id):
        return {"ok":true,"message":"Loot already saved"}
    d["gun_parts"] = int(d["gun_parts"]) + maxi(0, mini(200, parts))
    d["fabrication_tokens"] = int(d["fabrication_tokens"]) + maxi(0, mini(200, tokens))
    ids.append(run_id)
    if ids.size() > 1000:
        ids = ids.slice(ids.size() - 1000)
    d["processed_runs"] = ids
    return {"ok":_save(d),"message":"Salvage stored"}
