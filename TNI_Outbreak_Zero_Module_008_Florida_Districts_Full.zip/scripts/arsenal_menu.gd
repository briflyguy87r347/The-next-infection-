extends Control

var _list: VBoxContainer
var _message: Label
var _resource: Label

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var background := ColorRect.new()
	background.color = Color(0.06, 0.08, 0.085)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)
	var body := VBoxContainer.new()
	body.custom_minimum_size = Vector2(760, 0)
	scroll.add_child(body)
	var heading := Label.new()
	heading.text = "GUNSMITH — PERMANENT STARTING WEAPONS"
	heading.add_theme_font_size_override("font_size", 24)
	body.add_child(heading)
	var hint := Label.new()
	hint.text = "Crafted guns stay unlocked after death. Match Mystery Box guns do not."
	body.add_child(hint)
	_resource = Label.new()
	body.add_child(_resource)
	_list = VBoxContainer.new()
	body.add_child(_list)
	_message = Label.new()
	_message.custom_minimum_size.y = 50
	body.add_child(_message)
	var back := Button.new()
	back.text = "BACK TO MENU"
	back.custom_minimum_size.y = 48
	back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menu.tscn"))
	body.add_child(back)
	_refresh()

func _refresh() -> void:
	var d: Dictionary = WorldProgress.load_data()
	_resource.text = "GUN PARTS: %d    FABRICATION TOKENS: %d    EQUIPPED: %s" % [int(d["gun_parts"]),int(d["fabrication_tokens"]),str(d["starting_weapon"]).to_upper()]
	for child in _list.get_children():
		child.queue_free()
	for id in ["pistol", "smg", "shotgun", "rifle", "lmg"]:
		var owned: bool = (d["owned_weapons"] as Array).has(id)
		var b := Button.new()
		if id == "pistol":
			b.text = "SERVICE PISTOL — STARTER GUN — EQUIP"
		elif owned:
			b.text = "%s — OWNED — EQUIP" % str(WorldProgress.RECIPES[id]["name"])
		else:
			var recipe: Dictionary = WorldProgress.RECIPES[id]
			b.text = "%s — CRAFT %d PARTS + %d FAB" % [str(recipe["name"]), int(recipe["parts"]), int(recipe["tokens"])]
		b.custom_minimum_size.y = 48
		b.pressed.connect(_weapon_action.bind(id))
		_list.add_child(b)

func _weapon_action(id: String) -> void:
	var d: Dictionary = WorldProgress.load_data()
	var result: Dictionary = WorldProgress.equip(id) if (d["owned_weapons"] as Array).has(id) else WorldProgress.craft_gun(id)
	_refresh()
	_message.text = str(result.get("message", "Unknown result"))
