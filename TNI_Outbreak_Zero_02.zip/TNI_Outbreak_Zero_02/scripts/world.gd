extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const HUD_SCRIPT = preload("res://scripts/touch_hud.gd")
const ZOMBIE_SCRIPT = preload("res://scripts/zombie.gd")

var player: CharacterBody3D
var hud: Control
var targets: Array[StaticBody3D] = []
var health := 100
var kills := 0
var spawn_timer := 0.0
var game_over := false

func _ready() -> void:
	_build_environment()
	_build_player()
	_build_hud()
	for i in range(4):
		_spawn_zombie(Vector3(-8 + i * 5, 1.2, -19 - i * 4))
	hud.set_message("SURVIVE THE OUTBREAK")

func _make_box(name_text: String, pos: Vector3, size: Vector3, color: Color, solid: bool = true) -> Node3D:
	var root: Node3D
	if solid:
		root = StaticBody3D.new()
	else:
		root = Node3D.new()
	root.name = name_text
	root.position = pos
	add_child(root)
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	mesh_instance.material_override = material
	root.add_child(mesh_instance)
	if solid:
		var collider := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		collider.shape = shape
		root.add_child(collider)
	return root

func _build_environment() -> void:
	var sky := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.39, 0.56, 0.64)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.8, 0.84, 0.86)
	environment.ambient_light_energy = 0.7
	sky.environment = environment
	add_child(sky)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_energy = 1.15
	add_child(sun)
	_make_box("Ground", Vector3(0, -0.5, 0), Vector3(90, 1, 90), Color(0.23, 0.34, 0.22))
	_make_box("Road", Vector3(0, 0.015, -12), Vector3(12, 0.04, 65), Color(0.16, 0.17, 0.18), false)
	for i in range(10):
		_make_box("Road stripe", Vector3(0, 0.045, -39 + i * 6), Vector3(0.2, 0.025, 2.6), Color(0.93, 0.82, 0.43), false)
	for i in range(7):
		var side := -1 if i % 2 == 0 else 1
		var z := -31.0 + float(i) * 9.0
		_make_box("Abandoned house %d" % i, Vector3(side * 17, 2.4, z), Vector3(8, 4.8, 7), Color(0.43 + 0.04 * (i % 3), 0.41, 0.35))
		_make_box("Roof %d" % i, Vector3(side * 17, 5.05, z), Vector3(9, 0.5, 8), Color(0.25, 0.21, 0.2))
		_make_box("Door %d" % i, Vector3(side * 12.94, 1.15, z), Vector3(0.08, 2.3, 1.4), Color(0.18, 0.15, 0.12), false)
	for i in range(6):
		var target := _make_box("Practice target %d" % i, Vector3(-4 + (i % 3) * 4, 1.1, -8 - int(i / 3) * 9), Vector3(1.1, 2.2, 0.45), Color(0.5, 0.12, 0.12))
		if target is StaticBody3D:
			targets.append(target)
	_make_box("Spawn crate", Vector3(3.5, 0.65, 4), Vector3(2, 1.3, 2), Color(0.35, 0.26, 0.16))

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Survivor"
	player.position = Vector3(0, 2, 12)
	player.set_script(PLAYER_SCRIPT)
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Control.new()
	hud.set_script(HUD_SCRIPT)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(hud)
	hud.connect("move_changed", Callable(player, "set_move_input"))
	hud.connect("look_changed", Callable(player, "apply_look"))
	hud.connect("fire_requested", Callable(self, "fire_weapon"))

func _spawn_zombie(at: Vector3) -> void:
 var zombie := CharacterBody3D.new()
 zombie.name = "Infected"
 zombie.position = at
 zombie.set_script(ZOMBIE_SCRIPT)
 zombie.target = player
 add_child(zombie)
 zombie.attacked.connect(_on_attacked)

func _on_attacked(amount: int) -> void:
 if game_over:
  return
 health = maxi(0, health - amount)
 hud.set_stats(health, kills)
 if health == 0:
  game_over = true
  hud.set_message("YOU DIED - RESTART THE SCENE")

func _process(delta: float) -> void:
 if game_over:
  return
 spawn_timer += delta
 if spawn_timer >= 12.0 and get_tree().get_nodes_in_group("zombies").size() < 9:
  spawn_timer = 0.0
  var angle := randf() * TAU
  _spawn_zombie(player.global_position + Vector3(cos(angle) * 18.0, 1.2, sin(angle) * 18.0))

func fire_weapon() -> void:
 if game_over:
  return
	var camera: Camera3D = player.get_node("Camera3D")
	var origin := camera.global_position
	var end := origin + -camera.global_transform.basis.z * 100.0
	var query := PhysicsRayQueryParameters3D.create(origin, end)
	query.exclude = [player.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit["collider"].is_in_group("zombies"):
  var zombie: Node = hit["collider"]
  zombie.take_hit()
  if zombie.health <= 0:
   kills += 1
   hud.set_stats(health, kills)
   hud.set_message("INFECTED ELIMINATED")
  else:
   hud.set_message("HIT CONFIRMED")
 elif not hit.is_empty() and hit["collider"] in targets:
		var target: StaticBody3D = hit["collider"]
		targets.erase(target)
		target.queue_free()
		hud.set_message("TARGET HIT  |  %d LEFT" % targets.size())
	else:
		hud.set_message("SHOT FIRED")
