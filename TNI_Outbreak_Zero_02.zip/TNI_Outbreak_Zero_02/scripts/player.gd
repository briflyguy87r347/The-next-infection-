extends CharacterBody3D

const SPEED := 6.0
const LOOK_SENSITIVITY := 0.0035
const JUMP_VELOCITY := 6.5
var move_input := Vector2.ZERO
var camera: Camera3D

func _ready() -> void:
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.36
	capsule.height = 1.8
	collision.shape = capsule
	add_child(collision)
	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.position.y = 0.68
	camera.current = true
	add_child(camera)
	var gun := MeshInstance3D.new()
	gun.name = "PlaceholderWeapon"
	var gun_mesh := BoxMesh.new()
	gun_mesh.size = Vector3(0.19, 0.19, 0.75)
	gun.mesh = gun_mesh
	gun.position = Vector3(0.35, -0.29, -0.65)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.11, 0.12, 0.13)
	gun.material_override = mat
	camera.add_child(gun)

func set_move_input(direction: Vector2) -> void:
	move_input = direction.limit_length(1.0)

func apply_look(delta_pixels: Vector2) -> void:
	rotate_y(-delta_pixels.x * LOOK_SENSITIVITY)
	camera.rotation.x = clamp(camera.rotation.x - delta_pixels.y * LOOK_SENSITIVITY, -1.35, 1.35)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		apply_look(event.relative)
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not OS.has_feature("mobile"):
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= 19.6 * delta
	elif Input.is_key_pressed(KEY_SPACE):
		velocity.y = JUMP_VELOCITY
	var keyboard := Vector2.ZERO
	if Input.is_key_pressed(KEY_A): keyboard.x -= 1
	if Input.is_key_pressed(KEY_D): keyboard.x += 1
	if Input.is_key_pressed(KEY_W): keyboard.y -= 1
	if Input.is_key_pressed(KEY_S): keyboard.y += 1
	var direction := (transform.basis * Vector3(move_input.x + keyboard.x, 0, move_input.y + keyboard.y)).normalized()
	velocity.x = direction.x * SPEED
	velocity.z = direction.z * SPEED
	move_and_slide()
