extends CharacterBody3D
signal attacked(amount: int)
var target: Node3D
var health := 3
var attack_timer := 0.0
const SPEED := 2.1

func _ready() -> void:
 add_to_group("zombies")
 var shape := CollisionShape3D.new()
 var capsule := CapsuleShape3D.new()
 capsule.height = 1.8
 capsule.radius = 0.35
 shape.shape = capsule
 add_child(shape)
 var body := MeshInstance3D.new()
 var mesh := CapsuleMesh.new()
 mesh.radius = 0.35
 mesh.height = 1.8
 body.mesh = mesh
 var mat := StandardMaterial3D.new()
 mat.albedo_color = Color(0.22, 0.39, 0.23)
 body.material_override = mat
 add_child(body)
 var eyes := MeshInstance3D.new()
 var eye_mesh := BoxMesh.new()
 eye_mesh.size = Vector3(0.4, 0.1, 0.1)
 eyes.mesh = eye_mesh
 eyes.position = Vector3(0, 0.35, -0.32)
 var eye_mat := StandardMaterial3D.new()
 eye_mat.albedo_color = Color(0.9, 0.16, 0.08)
 eyes.material_override = eye_mat
 add_child(eyes)

func take_hit() -> void:
 health -= 1
 if health <= 0:
  queue_free()

func _physics_process(delta: float) -> void:
 if not is_instance_valid(target):
  return
 attack_timer = maxf(0.0, attack_timer - delta)
 var offset := target.global_position - global_position
 var distance := Vector2(offset.x, offset.z).length()
 if distance < 24.0 and distance > 1.4:
  var direction := Vector3(offset.x, 0, offset.z).normalized()
  velocity.x = direction.x * SPEED
  velocity.z = direction.z * SPEED
  look_at(global_position + Vector3(offset.x, 0, offset.z), Vector3.UP)
 else:
  velocity.x = 0
  velocity.z = 0
 if distance <= 1.6 and attack_timer <= 0.0:
  attacked.emit(10)
  attack_timer = 1.4
 if not is_on_floor():
  velocity.y -= 19.6 * delta
 else:
  velocity.y = 0
 move_and_slide()
