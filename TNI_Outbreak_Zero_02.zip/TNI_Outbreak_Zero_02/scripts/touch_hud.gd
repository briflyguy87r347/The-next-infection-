extends Control

signal move_changed(direction: Vector2)
signal look_changed(delta_pixels: Vector2)
signal fire_requested

var joystick_touch := -1
var look_touch := -1
var joystick_center := Vector2.ZERO
var joystick_vector := Vector2.ZERO
var message := "OUTBREAK ZERO  |  6 TARGETS"
var message_time := 0.0
var health := 100
var kills := 0

func set_stats(hp: int, score: int) -> void:
 health = hp
 kills = score
 queue_redraw()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	joystick_center = Vector2(125, get_viewport_rect().size.y - 125)
	queue_redraw()

func _process(delta: float) -> void:
	if message_time > 0.0:
		message_time -= delta
		if message_time <= 0.0:
			message = "OUTBREAK ZERO  |  FIND THE TARGETS"
			queue_redraw()

func set_message(value: String) -> void:
	message = value
	message_time = 2.0
	queue_redraw()

func _fire_center() -> Vector2:
	var s := get_viewport_rect().size
	return Vector2(s.x - 105, s.y - 120)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.distance_to(_fire_center()) < 85:
				fire_requested.emit()
			elif event.position.x < get_viewport_rect().size.x * 0.45 and joystick_touch == -1:
				joystick_touch = event.index
				joystick_center = event.position
				joystick_vector = Vector2.ZERO
				move_changed.emit(joystick_vector)
			elif look_touch == -1:
				look_touch = event.index
		else:
			if event.index == joystick_touch:
				joystick_touch = -1
				joystick_vector = Vector2.ZERO
				move_changed.emit(joystick_vector)
			if event.index == look_touch:
				look_touch = -1
		queue_redraw()
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch:
			joystick_vector = ((event.position - joystick_center) / 75.0).limit_length(1.0)
			move_changed.emit(Vector2(joystick_vector.x, -joystick_vector.y))
			queue_redraw()
		elif event.index == look_touch:
			look_changed.emit(event.relative)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if event.position.distance_to(_fire_center()) < 85:
			fire_requested.emit()

func _draw() -> void:
	var s := get_viewport_rect().size
	draw_circle(joystick_center, 76, Color(0.1, 0.15, 0.17, 0.4))
	draw_arc(joystick_center, 76, 0, TAU, 48, Color(0.8, 0.9, 0.85, 0.65), 3)
	draw_circle(joystick_center + joystick_vector * 60, 30, Color(0.75, 0.88, 0.82, 0.6))
	draw_circle(_fire_center(), 67, Color(0.65, 0.12, 0.12, 0.52))
	draw_arc(_fire_center(), 67, 0, TAU, 48, Color(1, 0.8, 0.75, 0.8), 3)
	draw_line(Vector2(s.x/2 - 12, s.y/2), Vector2(s.x/2 + 12, s.y/2), Color.WHITE, 2)
	draw_line(Vector2(s.x/2, s.y/2 - 12), Vector2(s.x/2, s.y/2 + 12), Color.WHITE, 2)
	draw_string(ThemeDB.fallback_font, Vector2(24, 38), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
	draw_string(ThemeDB.fallback_font, Vector2(24, 70), "HEALTH: %d    KILLS: %d" % [health, kills], HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 0.85, 0.7))
	draw_string(ThemeDB.fallback_font, _fire_center() + Vector2(-25, 7), "FIRE", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
