# THE NEXT INFECTION — Outbreak Zero 02

Android-first Godot 4 3D FPS prototype, using only original procedural primitives and GDScript. Adds four chasing zombies, health, damage, shooting zombies, kills, and timed zombie spawning to Prototype 01. No external assets or paid services.

## Android installation
1. Download ZIP and extract with Android Files.
2. In Godot Android Editor select **Import**, browse to `TNI_Outbreak_Zero_02/project.godot` and open it.
3. Press Play. Landscape recommended.
4. Left thumb moves; drag right side to look; FIRE shoots. Zombies chase and attack at close range. Health starts at 100. Restart scene after death.

This is a local prototype. No online servers, real-money payments, inventory, or property economy. Not tested on your specific tablet. If Godot shows errors, send screenshot and Godot version.
